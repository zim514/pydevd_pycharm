f=lambda x: 'val=%s' % x
